
import { BrowserRouter, Route, Routes} from 'react-router-dom';
import Signup from './Signup';
import Posts from './postes/PostCard';
import Page from './postes/PostPage';
const App = () => {
  return (
    <BrowserRouter>
      <div>
        <Routes>
          <Route path="/" element={<Signup />} />
          <Route path="/posts" element={<Posts/>}/>
          <Route path="/page" element={<Page/>}/>
        </Routes>
      </div>
    </BrowserRouter>
  );
};

export default App;